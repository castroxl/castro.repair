# -*- coding: utf-8 -*-

import sys
import json
import urllib.parse
import urllib.request
import urllib.error
from datetime import datetime
import time

import xbmc
import xbmcplugin
import xbmcgui
import xbmcaddon

# ===============================
# CONFIG
# ===============================

BASE_URL = "https://speedtv.x44bet.com"
TIMEOUT = 15
MAX_RETRY_504 = 2

HANDLE = int(sys.argv[1])
ADDON = xbmcaddon.Addon()

# ===============================
# HTTP
# ===============================

def http_get(url):
    req = urllib.request.Request(
        url,
        headers={"User-Agent": "Kodi-SpeedTV"}
    )
    return urllib.request.urlopen(req, timeout=TIMEOUT)

# ===============================
# LOGIN
# ===============================

def get_credentials():

    user = ADDON.getSetting("user")
    password = ADDON.getSetting("pass")

    if user and password:
        if validar_login(user, password):
            return user, password
        else:
            ADDON.setSetting("user", "")
            ADDON.setSetting("pass", "")

    user = xbmcgui.Dialog().input(
        "Usuário SpeedTV",
        type=xbmcgui.INPUT_ALPHANUM
    )

    if not user:
        sys.exit()

    password = xbmcgui.Dialog().input(
        "Senha SpeedTV",
        type=xbmcgui.INPUT_ALPHANUM,
        option=xbmcgui.ALPHANUM_HIDE_INPUT
    )

    if not password:
        sys.exit()

    if validar_login(user, password):
        ADDON.setSetting("user", user)
        ADDON.setSetting("pass", password)
        return user, password

    xbmcgui.Dialog().ok("SpeedTV", "Usuário ou senha inválidos")
    sys.exit()


def validar_login(user, password):
    try:
        params = urllib.parse.urlencode({
            "user": user,
            "pass": password
        })

        url = f"{BASE_URL}/api/user/info?{params}"

        with http_get(url) as r:
            return r.status == 200

    except:
        return False


USER, PASS = get_credentials()

# ===============================
# STATUS DA API
# ===============================

def verificar_status_api():
    try:
        with http_get(f"{BASE_URL}/api/status") as r:
            return json.loads(r.read().decode("utf-8"))
    except:
        return None

# ===============================
# ERROS
# ===============================

def tratar_http_erro(e):

    data = {}
    try:
        body = e.read().decode("utf-8")
        data = json.loads(body)
    except:
        pass

    if e.code == 401:
        xbmcgui.Dialog().ok("SpeedTV", "Credenciais inválidas ou assinatura expirada.")
        ADDON.setSetting("user", "")
        ADDON.setSetting("pass", "")
        sys.exit()

    elif e.code == 403:
        xbmcgui.Dialog().ok(
            "SpeedTV",
            data.get("message", "Acesso negado para esta funcionalidade.")
        )

    elif e.code == 429:
        xbmcgui.Dialog().ok(
            "SpeedTV",
            data.get("message", "Limite de conexões atingido.")
        )

    elif e.code == 503:
        xbmcgui.Dialog().ok(
            "SpeedTV",
            data.get("message", "Funcionalidade em breve.")
        )

    elif e.code == 504:
        xbmcgui.Dialog().ok(
            "SpeedTV",
            "Stream ainda não disponível.\nTente novamente em alguns segundos."
        )

    elif e.code == 404:
        xbmcgui.Dialog().ok(
            "SpeedTV",
            "Conteúdo não encontrado."
        )

    else:
        xbmcgui.Dialog().ok(
            "SpeedTV",
            "Erro da API (%d)" % e.code
        )

# ===============================
# API BASE
# ===============================

def api_get(path):
    try:
        params = urllib.parse.urlencode({
            "user": USER,
            "pass": PASS
        })

        url = f"{BASE_URL}{path}?{params}"

        with http_get(url) as r:
            return json.loads(r.read().decode("utf-8"))

    except urllib.error.HTTPError as e:
        tratar_http_erro(e)
        return None

    except Exception as e:
        xbmcgui.Dialog().ok("SpeedTV", "Erro de rede:\n%s" % e)
        return None

# ===============================
# APIs
# ===============================

def jogos_get():
    return api_get("/api/jogos")

def epgs_get():
    return api_get("/api/epgs")

def filmes_get():
    return api_get("/api/filmes")

def series_get():
    return api_get("/api/series")

def user_info_get():
    return api_get("/api/user/info")

# ===============================
# MENU
# ===============================

def menu_principal():

    status = verificar_status_api()

    if status and not status.get("apiOnline", True):
        xbmcgui.Dialog().notification(
            "SpeedTV",
            status.get("message", "API offline"),
            xbmcgui.NOTIFICATION_WARNING,
            5000
        )

    menus = [
        ("📺 Canais", "canais"),
        ("🗂️ Categorias", "categorias"),
        ("⚽ Jogos do Dia", "jogos"),
        ("🎬 Filmes", "filmes"),
        ("📺 Séries", "series"),
        ("👤 Minha Conta", "perfil"),
    ]

    for label, mode in menus:
        li = xbmcgui.ListItem(label=label)
        url = f"{sys.argv[0]}?mode={mode}"
        xbmcplugin.addDirectoryItem(HANDLE, url, li, True)

    xbmcplugin.endOfDirectory(HANDLE)

# ===============================
# CANAIS + EPG
# ===============================

def listar_canais():

    data = api_get("/api/channels")
    if not data:
        return

    epgs = epgs_get() or []
    epg_map = {i["id"]: i.get("epg") for i in epgs}

    for canal in data.get("channels", []):

        epg = epg_map.get(canal.get("id"))
        label = canal.get("name", "Canal")

        if epg and epg.get("title"):
            label += "  -  " + epg.get("title")

        li = xbmcgui.ListItem(label=label)

        li.setArt({
            "thumb": canal.get("image", ""),
            "icon": canal.get("image", "")
        })

        li.setProperty("IsPlayable", "true")

        url = f"{sys.argv[0]}?play={canal.get('id')}"
        xbmcplugin.addDirectoryItem(HANDLE, url, li, False)

    xbmcplugin.endOfDirectory(HANDLE)

# ===============================
# CATEGORIAS
# ===============================

def listar_categorias():

    data = api_get("/api/channels")
    if not data:
        return

    cats = data.get("categories", [])

    for c in cats:
        li = xbmcgui.ListItem(label=c.get("name", "Categoria"))
        url = f"{sys.argv[0]}?mode=cat&id={c.get('id')}"
        xbmcplugin.addDirectoryItem(HANDLE, url, li, True)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_canais_categoria(cat_id):

    data = api_get("/api/channels")
    if not data:
        return

    for canal in data.get("channels", []):

        if cat_id not in canal.get("categories", []):
            continue

        li = xbmcgui.ListItem(label=canal.get("name", "Canal"))
        li.setArt({"thumb": canal.get("image", "")})
        li.setProperty("IsPlayable", "true")

        url = f"{sys.argv[0]}?play={canal.get('id')}"
        xbmcplugin.addDirectoryItem(HANDLE, url, li, False)

    xbmcplugin.endOfDirectory(HANDLE)

# ===============================
# LIGAS / JOGOS
# ===============================

def listar_ligas():

    jogos = jogos_get()
    if not jogos:
        return

    ligas = {}

    for jogo in jogos:
        liga = jogo.get("data", {}).get("league", "Outros")
        ligas.setdefault(liga, []).append(jogo)

    for liga in sorted(ligas.keys()):
        li = xbmcgui.ListItem(label="🏆 " + liga)
        url = f"{sys.argv[0]}?mode=liga&nome={urllib.parse.quote(liga)}"
        xbmcplugin.addDirectoryItem(HANDLE, url, li, True)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_jogos_por_liga(nome_liga):

    jogos = jogos_get()
    if not jogos:
        return

    for jogo in jogos:

        if jogo.get("data", {}).get("league") != nome_liga:
            continue

        titulo = jogo.get("title", "Jogo")
        imagem = jogo.get("image", "")
        players = jogo.get("players", [])

        start_ts = jogo.get("data", {}).get("timer", {}).get("start")

        hora = ""
        if start_ts:
            try:
                hora = datetime.fromtimestamp(start_ts).strftime("%H:%M")
            except:
                pass

        label = f"{hora} - {titulo}" if hora else titulo

        for player in players:

            canal_id = player.rstrip("/").split("/")[-1]

            li = xbmcgui.ListItem(label=label)
            li.setArt({"thumb": imagem})
            li.setProperty("IsPlayable", "true")

            url = f"{sys.argv[0]}?play={canal_id}"
            xbmcplugin.addDirectoryItem(HANDLE, url, li, False)

    xbmcplugin.endOfDirectory(HANDLE)

# ===============================
# FILMES / SERIES
# ===============================

def listar_filmes():
    data = filmes_get()
    if not data:
        return

    xbmcgui.Dialog().ok("SpeedTV", "Catálogo de filmes em breve.")
    xbmcplugin.endOfDirectory(HANDLE)


def listar_series():
    data = series_get()
    if not data:
        return

    xbmcgui.Dialog().ok("SpeedTV", "Catálogo de séries em breve.")
    xbmcplugin.endOfDirectory(HANDLE)

# ===============================
# PERFIL
# ===============================

def mostrar_perfil():

    info = user_info_get()
    if not info:
        return

    linhas = []

    linhas.append("Usuário: %s" % info.get("user"))
    linhas.append("Plano: %s" % info.get("plan"))
    linhas.append("Status: %s" % info.get("subscription", {}).get("status"))
    linhas.append("Máx conexões: %s" % info.get("maxConnections"))

    exp = info.get("subscription", {}).get("expiresAt")
    if exp:
        linhas.append("Expira em: %s" % exp)
    else:
        linhas.append("Expiração: ilimitada")

    xbmcgui.Dialog().textviewer("Minha Conta", "\n".join(linhas))

# ===============================
# PLAY COM RETRY
# ===============================

def play_canal(canal_id, tentativa=0):

    try:
        data = api_get(f"/api/channel/{canal_id}")
        if not data:
            return

        stream_url = data.get("m3u8") or data.get("stream")

        if not stream_url:
            xbmcgui.Dialog().ok("SpeedTV", "Stream inválido.")
            return

        try:
            parsed = urllib.parse.urlparse(stream_url)
            qs = urllib.parse.parse_qs(parsed.query)
            token = qs.get("token", [None])[0]

            if token:
                stream_url = f"{BASE_URL}/stream/kodi/{token}/canal.m3u8"
        except:
            pass

        item = xbmcgui.ListItem(path=stream_url)
        item.setMimeType("application/vnd.apple.mpegurl")
        item.setContentLookup(False)

        xbmcplugin.setResolvedUrl(HANDLE, True, item)

    except urllib.error.HTTPError as e:
        if e.code == 504 and tentativa < MAX_RETRY_504:
            time.sleep(2)
            play_canal(canal_id, tentativa + 1)
        else:
            tratar_http_erro(e)

# ===============================
# ROTEADOR
# ===============================

args = sys.argv[2]

if args.startswith("?play="):
    play_canal(args.replace("?play=", ""))

elif args.startswith("?mode=liga"):
    params = urllib.parse.parse_qs(args.replace("?", ""))
    listar_jogos_por_liga(params.get("nome", [""])[0])

elif args.startswith("?mode=jogos"):
    listar_ligas()

elif args.startswith("?mode=canais"):
    listar_canais()

elif args.startswith("?mode=categorias"):
    listar_categorias()

elif args.startswith("?mode=cat"):
    params = urllib.parse.parse_qs(args.replace("?", ""))
    try:
        cid = int(params.get("id", [0])[0])
    except:
        cid = 0
    listar_canais_categoria(cid)

elif args.startswith("?mode=filmes"):
    listar_filmes()

elif args.startswith("?mode=series"):
    listar_series()

elif args.startswith("?mode=perfil"):
    mostrar_perfil()

else:
    menu_principal()
