import sys
import json
import urllib.parse
import urllib.request
from datetime import datetime
import xbmc
import xbmcplugin
import xbmcgui

# ===============================
# CONFIGURAÇÃO
# ===============================
BASE_URL = "https://speedtv.x44bet.com"
USER = "kodi"
PASS = "424tmmtku887eawa9ake9o5uitvrck"
TIMEOUT = 15

JOGOS_API = "https://embedtv.best/api/jogos"

HANDLE = int(sys.argv[1])

# ===============================
# API SPEEDTV
# ===============================
def api_get(path):
    try:
        params = urllib.parse.urlencode({
            "user": USER,
            "pass": PASS
        })

        url = f"{BASE_URL}{path}?{params}"

        req = urllib.request.Request(
            url,
            headers={"User-Agent": "Kodi-SpeedTV"}
        )

        with urllib.request.urlopen(req, timeout=TIMEOUT) as response:
            return json.loads(response.read().decode("utf-8"))

    except Exception as e:
        xbmcgui.Dialog().ok("SpeedTV", f"Erro na API:\n{e}")
        return None

# ===============================
# API JOGOS
# ===============================
def jogos_get():
    try:
        req = urllib.request.Request(
            JOGOS_API,
            headers={"User-Agent": "Kodi-SpeedTV"}
        )
        with urllib.request.urlopen(req, timeout=TIMEOUT) as response:
            return json.loads(response.read().decode("utf-8"))
    except Exception as e:
        xbmcgui.Dialog().ok("SpeedTV", f"Erro ao carregar jogos:\n{e}")
        return None

# ===============================
# MENU PRINCIPAL
# ===============================
def menu_principal():
    menus = [
        ("📺 Canais", "canais"),
        ("⚽ Jogos do Dia", "jogos")
    ]

    for label, mode in menus:
        li = xbmcgui.ListItem(label=label)
        url = f"{sys.argv[0]}?mode={mode}"
        xbmcplugin.addDirectoryItem(HANDLE, url, li, True)

    xbmcplugin.endOfDirectory(HANDLE)

# ===============================
# LISTAR CANAIS
# ===============================
def listar_canais():
    data = api_get("/api/channels")
    if not data:
        return

    for canal in data.get("channels", []):
        li = xbmcgui.ListItem(label=canal.get("name", "Canal"))
        li.setArt({
            "thumb": canal.get("image", ""),
            "icon": canal.get("image", "")
        })
        li.setProperty("IsPlayable", "true")

        url = f"{sys.argv[0]}?play={canal.get('id')}"
        xbmcplugin.addDirectoryItem(HANDLE, url, li, False)

    xbmcplugin.endOfDirectory(HANDLE)

# ===============================
# LISTAR LIGAS
# ===============================
def listar_ligas():
    jogos = jogos_get()
    if not jogos:
        return

    ligas = {}

    for jogo in jogos:
        liga = jogo.get("data", {}).get("league", "Outros")
        ligas.setdefault(liga, []).append(jogo)

    for liga in sorted(ligas.keys()):
        li = xbmcgui.ListItem(label=f"🏆 {liga}")
        url = f"{sys.argv[0]}?mode=liga&nome={urllib.parse.quote(liga)}"
        xbmcplugin.addDirectoryItem(HANDLE, url, li, True)

    xbmcplugin.endOfDirectory(HANDLE)

# ===============================
# LISTAR JOGOS POR LIGA
# ===============================
def listar_jogos_por_liga(nome_liga):
    jogos = jogos_get()
    if not jogos:
        return

    for jogo in jogos:
        liga = jogo.get("data", {}).get("league", "")
        if liga != nome_liga:
            continue

        titulo = jogo.get("title", "Jogo")
        imagem = jogo.get("image", "")
        players = jogo.get("players", [])

        start_ts = jogo.get("data", {}).get("timer", {}).get("start")
        if start_ts:
            hora = datetime.fromtimestamp(start_ts).strftime("%H:%M")
            label = f"{hora} - {titulo}"
        else:
            label = titulo

        for player_url in players:
            canal_id = player_url.rstrip("/").split("/")[-1]

            li = xbmcgui.ListItem(label=label)
            li.setArt({"thumb": imagem, "icon": imagem})
            li.setProperty("IsPlayable", "true")

            url = f"{sys.argv[0]}?play={canal_id}"
            xbmcplugin.addDirectoryItem(HANDLE, url, li, False)

    xbmcplugin.endOfDirectory(HANDLE)

# ===============================
# PLAY
# ===============================
def play_canal(canal_id):
    xbmcgui.Dialog().notification(
        "SpeedTV",
        "Carregando transmissão...",
        xbmcgui.NOTIFICATION_INFO,
        2000
    )

    data = api_get(f"/api/channel/{canal_id}")
    if not data:
        return

    m3u8 = data.get("m3u8")
    if not m3u8:
        xbmcgui.Dialog().ok("SpeedTV", "Stream inválido")
        return

    item = xbmcgui.ListItem(path=m3u8)
    xbmcplugin.setResolvedUrl(HANDLE, True, item)

# ===============================
# ROTEADOR
# ===============================
args = sys.argv[2]

if args.startswith("?play="):
    play_canal(args.replace("?play=", ""))

elif args.startswith("?mode=liga"):
    params = urllib.parse.parse_qs(args.replace("?", ""))
    nome_liga = params.get("nome", [""])[0]
    listar_jogos_por_liga(nome_liga)

elif args.startswith("?mode=jogos"):
    listar_ligas()

elif args.startswith("?mode=canais"):
    listar_canais()

else:
    menu_principal()